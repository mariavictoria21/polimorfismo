/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.polimorfismo;

/**
 *
 * @author Maria Victoria
 */
public class Polimorfismo {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
public class Main {
    public static void main(String[] args) {
        Animal myAnimal = new Animal();  // Creación de un objeto Animal
        Animal myDog = new Dog();        // Creación de un objeto Dog
        Animal myCat = new Cat();        // Creación de un objeto Cat

        myAnimal.sound();  // Llamada al método en Animal
        myDog.sound();     // Llamada al método en Dog (polimorfismo)
        myCat.sound();     // Llamada al método en Cat (polimorfismo)
    }
}
