public class Cat extends Animal {
    @Override
    public void sound() {
        System.out.println("The cat meows");
    }
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Maria Victoria
 */
public class cat {
    
}
